# Alexandra Montgomery
# 7/5/2017 - 7/9/2017

# Resubmitting to fix 


class MyTime:
   def __init__(self, hrs=0, mins=0, secs=0):
      # Calculate total seconds to represent
      # abs around the imputs makes sure all inputs are positive numbers, even if give negative entries
      #This defeats the purpose of having an "if_negative" function and simplifies the purpose
      totalsecs = abs(hrs*3600 + mins*60 + secs)
      self.hours = abs(totalsecs // 3600)        # Split in h, m, s
      leftoversecs = abs(totalsecs % 3600)
      self.minutes = abs(leftoversecs // 60)
      self.seconds = abs(leftoversecs % 60)
      
   def increment(self, secs):
      self.seconds += secs
# if the seconds is in the negative it will deduct from the minutes
      while self.seconds < 0: 
         self.minutes -= 1
         self.seconds += 60

      while self.seconds >= 60: 
         self.seconds -= 60
         self.minutes += 1

      while self.minutes >= 60:
         self.minutes -= 60
         self.hours +=1

      while self.hours >= 24:
         self.hours -= 24
         self.days += 1
           
   def get_sec(self):
      return(self.hours*3600) + (self.minutes * 60) + self.seconds
   
   def __str__(self):
      return '{:02d}:{:02d}:{:02d}'.\
             format(self.hours, self.minutes, self.seconds)

def between(t1, t, t2):
   return t1.get_sec() <= t.get_sec() <= t2.get_sec() \
            or t2.get_sec() <= t.get_sec() <= t1.get_sec()
 

#assign the values of t1, t2, and t (prints to show)
t1 = MyTime(0, 0, 1)
print("t1 =", t1)
t2 = MyTime(5, 0, 4)
print("t2 =", t2)
t = MyTime(1, 0, 0)
print("t =", t)

#run the between funtion with given values
print("between (t1, t2, t3) = ", between( t1, t, t2))

