# Alexandra Montgomery
# 6/26/17 - 7/2/2017


'''Student Note: I was going to make this all extensive and run
the code as a Gui, but figured just having it work as told would work
for full points too and save the complication. Here is my very basic
program,and yes, I did create this as a Gui too.'''


class Account:
    def __init__(self, first_name, last_name, initial_deposit=0):
        #creates an account with the users name and opening balance
        self.first_name = first_name # first name
        self.last_name = last_name # last name
        self.balance = initial_deposit # initial deposit
        self.full = first_name + " " + last_name
        
    def deposit(self, amount):
        #Adds to the balance of the account if a deposit is made
        self.balance += amount
        return self.balance
        
    def withdraw(self, amount):
        #Withdraws an amount from the balance
        if amount > self.balance:
            print("Insufficient funds, your balance is:")
        else:
            self.balance -= amount
        return self.balance

    def fee_calculations(self):
        #change fee if under certain balance
        if self.balance < 1000:
            self.balance -= 10
            print("You have had a $10 fee this month, increast your balance next month to avoid a fee.")
        else:
            print("Your balance is above the minimum, no fee")
            
        """I could have made a variable time and took out all the fees for a certain time
        but there's no real time here so let's assume this is all
        one day and the max I could take out as a fee is $10."""
        
        return self.balance
        
    def interest(self):
        interest_rate = 0.03 # set annually after 1 year calculate the interest and new balance
        oneYearInterest = interest_rate * self.balance
        print("The interst you'd recieve after 1 year with a 3% interest is:", oneYearInterest)

    def show(self):
        #Show user the info 
        print("Thank you ", self.full, " for using our bank.")
        print("You have a final balance of: ", self.balance)
        
