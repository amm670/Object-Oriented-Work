#Alexandra Montgomery
#7/17/17 - 7/20/17

class Ball():
    def __init__ (self, x, y, vx, vy):
        self.xPos = x
        self.yPos = y
        self.xVec = vx
        self.yVec = vy
        
    def getXPos(self):
        return self.xPos

    def getYPos(self):
        return self.yPos

    def getXVel(self):
        return self.xVec

    def getYVel(self):
        return self.yVec

    def advance(self, timestep=1):
        self.xPos += self.xVec *timestep
        self.yPos += self.yVec *timestep
        return ("X position:", self.xPos, "Y position:", self.yPos )


    def bounce(self, heightstep=-1):
        token = 0
        while token < 4:
            token = token + 1
            self.yPos = self.yPos * heightstep
            self.yVec = self.yVec * heightstep
            print("Bounce Number:", token, ("Y Position", self.yPos, "Y Velocity", self.yVec))
            print("Thanks for bouncing!")

        
        
