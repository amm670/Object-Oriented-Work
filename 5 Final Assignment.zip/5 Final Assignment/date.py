# Alexandra Montgomery
# 7/17/17 - 7/20/17

class Date:
    def __init__ (self, month, day, year):
        self.month = month
        self.day = day
        self.year = year        

    def advance(self):
        self.day += 1
        monthLengths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if self.day > monthLengths[self.month-1]:
            self.day = 1
            self.month += 1
        if self.month > 12:
            self.month = 1
            self.year += 1
        return "{}/{}/{}".format(self.month, self.day, self.year)
            

    #recognizes the month by the number entered and returns accordingly with the entered day
    def __str__(self):
        if self.month == 1:
            return "January " + str(self.day)
        elif self.month == 2:
            return "February " + str(self.day)
        elif self.month == 3:
            return "March " + str(self.day)
        elif self.month == 4:
            return "April " + str(self.day)
        elif self.month == 5:
            return "May " + str(self.day)
        elif self.month == 6:
            return "June " + str(self.day)
        elif self.month == 7:
            return "July " + str(self.day)
        elif self.month == 8:
            return "August " + str(self.day)
        elif self.month == 9:
             "September " + str(self.day)
        elif self.month == 10:
            return "October " + str(self.day)
        elif self.month == 11:
            return "November " + str(self.day)
        elif self.month == 12:
            return "December " + str(self.day)
        else:
            #if month entered is greater than 12
            return "Thats not a valid date"


       
