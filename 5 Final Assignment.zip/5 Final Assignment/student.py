# Alexandra Montgomery
# 7/17/17 - 7/20/17

class Student():
    def __init__(self, ID, lastname, credits = None, courseLoad = None):
        self.ID = ID
        
        self.lastname = str(lastname)
        self.credits = credits
        self.courseLoad = courseLoad

#only have user input the number of credits they are adding
#basically one course at a time)
#set course load - I asked about this
    def registerCurrent(self, credits):
        if credits <= 0 or credits >=5:
            print("Your class must have a credit value between 1-4, try again")
        else:
            self.courseLoad = self.courseLoad + credits
            print("Your are adding a class that has a credit value of " ,credits, "Your current course load is:")
            return self.courseLoad

        
    def withdraw(self):
        if self.courseLoad >= 1:
            self.courseLoad -= 1
            return ("Your course load will be ") + str(self.courseLoad)
        else:
            return ("Your course load cannot be less than 0.")

    def passedCourse(self, credits):
        if self.courseLoad - credits < 0:
            print("NOPE! You can't pass a class you weren't taking!!")
        elif credits <= 0 or credits >=5:
            print("Your class must have a credit value between 1-4, try again")
        else:
            print("Congrats you've finished a course!")
            self.courseLoad -= credits
            self.credits += credits
            print("Your have finished a total of", self.credits, "credits")
            print("Your current course load is: ", self.courseLoad)
            return self.credits, self.courseLoad
        
#creates Email using initial information by making strings and adding them together
    def createdEmail(self):
        return str(self.lastname)+ str(self.ID)+"@rutgers.edu"
